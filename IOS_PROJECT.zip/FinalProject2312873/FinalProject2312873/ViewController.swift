//
//  ViewController.swift
//  FinalProject2312873
//
//  Created by english on 2024-04-02.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func LoginButtonPressed(_ sender: UIButton) {
    }
    
}

